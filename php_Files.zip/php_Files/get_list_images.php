<?php

$return_array = array();

if ($handle = opendir('uploads/.')) {
  

    while (false !== ($file = readdir($handle))) {
        if($file == "." or $file == "..")
        {
        }
        else
        {
            $return_array[] = $file;
        }
    }
    echo json_encode($return_array);
    closedir($handle);
}
?>