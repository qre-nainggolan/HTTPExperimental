<?php
$name = $_GET['name'];

//Delete particular file from folder
$folders = glob('Uploads/'.$name); //get file name
foreach($folders as $file){
    if(is_file($file))
    unlink($file); //delete file
}

?>

