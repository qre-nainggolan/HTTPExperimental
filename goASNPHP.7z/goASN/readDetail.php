<?php
$code = "";
require_once('connection.php');
$code = "TIU";
$code = $_POST['code'];

$result = array();

$query = mysqli_query($CON,"SELECT code, title, question, optionA, optionB, optionC, optionD, optionE, 
						answerLetter, answerText, orderPosition FROM question_test WHERE code = '". $code ."' ORDER BY orderPosition DESC LIMIT 0,1");

// $query = mysqli_query($CON,"SELECT * FROM tb_student ORDER BY nim DESC");
while($row = mysqli_fetch_assoc($query)){
  $result[] = $row;
}

echo json_encode(array('result'=>$result));

?>

