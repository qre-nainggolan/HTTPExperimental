package b4a.example.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_1{

public static void LS_320x480_1(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 2;BA.debugLine="Panel1.Width = 100%x"[1/320x480,scale=1]
views.get("panel1").vw.setWidth((int)((100d / 100 * width)));
//BA.debugLineNum = 3;BA.debugLine="Panel1.Height = 100%y"[1/320x480,scale=1]
views.get("panel1").vw.setHeight((int)((100d / 100 * height)));
//BA.debugLineNum = 5;BA.debugLine="btn_Select_Image.Left = Panel1.Left + 10dip"[1/320x480,scale=1]
views.get("btn_select_image").vw.setLeft((int)((views.get("panel1").vw.getLeft())+(10d * scale)));
//BA.debugLineNum = 6;BA.debugLine="btn_Display_Image_From_Server.Left = Panel1.Left + 10dip"[1/320x480,scale=1]
views.get("btn_display_image_from_server").vw.setLeft((int)((views.get("panel1").vw.getLeft())+(10d * scale)));
//BA.debugLineNum = 8;BA.debugLine="btn_Resize_Image_Save_Upload.Left = btn_Select_Image.Right + 10dip"[1/320x480,scale=1]
views.get("btn_resize_image_save_upload").vw.setLeft((int)((views.get("btn_select_image").vw.getLeft() + views.get("btn_select_image").vw.getWidth())+(10d * scale)));
//BA.debugLineNum = 9;BA.debugLine="btn_Delete_Image_from_Server.Left = btn_Select_Image.Right + 10dip"[1/320x480,scale=1]
views.get("btn_delete_image_from_server").vw.setLeft((int)((views.get("btn_select_image").vw.getLeft() + views.get("btn_select_image").vw.getWidth())+(10d * scale)));
//BA.debugLineNum = 12;BA.debugLine="btn_Select_Image.Top = Panel1.Top + 10dip"[1/320x480,scale=1]
views.get("btn_select_image").vw.setTop((int)((views.get("panel1").vw.getTop())+(10d * scale)));
//BA.debugLineNum = 13;BA.debugLine="btn_Resize_Image_Save_Upload.Top = Panel1.Top + 10dip"[1/320x480,scale=1]
views.get("btn_resize_image_save_upload").vw.setTop((int)((views.get("panel1").vw.getTop())+(10d * scale)));
//BA.debugLineNum = 14;BA.debugLine="btn_Display_Image_From_Server.Top = btn_Select_Image.Bottom + 5dip"[1/320x480,scale=1]
views.get("btn_display_image_from_server").vw.setTop((int)((views.get("btn_select_image").vw.getTop() + views.get("btn_select_image").vw.getHeight())+(5d * scale)));
//BA.debugLineNum = 15;BA.debugLine="btn_Delete_Image_from_Server.Top = btn_Resize_Image_Save_Upload.Bottom + 5dip"[1/320x480,scale=1]
views.get("btn_delete_image_from_server").vw.setTop((int)((views.get("btn_resize_image_save_upload").vw.getTop() + views.get("btn_resize_image_save_upload").vw.getHeight())+(5d * scale)));
//BA.debugLineNum = 18;BA.debugLine="btn_Select_Image.Width = Panel1.Width / 2 - 20dip"[1/320x480,scale=1]
views.get("btn_select_image").vw.setWidth((int)((views.get("panel1").vw.getWidth())/2d-(20d * scale)));
//BA.debugLineNum = 19;BA.debugLine="btn_Resize_Image_Save_Upload.Width = btn_Select_Image.Width"[1/320x480,scale=1]
views.get("btn_resize_image_save_upload").vw.setWidth((int)((views.get("btn_select_image").vw.getWidth())));
//BA.debugLineNum = 20;BA.debugLine="btn_Display_Image_From_Server.Width = btn_Select_Image.Width"[1/320x480,scale=1]
views.get("btn_display_image_from_server").vw.setWidth((int)((views.get("btn_select_image").vw.getWidth())));
//BA.debugLineNum = 21;BA.debugLine="btn_Delete_Image_from_Server.Width = btn_Select_Image.Width"[1/320x480,scale=1]
views.get("btn_delete_image_from_server").vw.setWidth((int)((views.get("btn_select_image").vw.getWidth())));
//BA.debugLineNum = 23;BA.debugLine="btn_Resize_Image_Save_Upload.Right = Panel1.Right - 10dip"[1/320x480,scale=1]
views.get("btn_resize_image_save_upload").vw.setLeft((int)((views.get("panel1").vw.getLeft() + views.get("panel1").vw.getWidth())-(10d * scale) - (views.get("btn_resize_image_save_upload").vw.getWidth())));
//BA.debugLineNum = 24;BA.debugLine="btn_Delete_Image_from_Server.Right = Panel1.Right - 10dip"[1/320x480,scale=1]
views.get("btn_delete_image_from_server").vw.setLeft((int)((views.get("panel1").vw.getLeft() + views.get("panel1").vw.getWidth())-(10d * scale) - (views.get("btn_delete_image_from_server").vw.getWidth())));
//BA.debugLineNum = 27;BA.debugLine="btn_Delete_All_Image_From_Server.Top = btn_Display_Image_From_Server.Bottom + 5dip"[1/320x480,scale=1]
views.get("btn_delete_all_image_from_server").vw.setTop((int)((views.get("btn_display_image_from_server").vw.getTop() + views.get("btn_display_image_from_server").vw.getHeight())+(5d * scale)));
//BA.debugLineNum = 28;BA.debugLine="btn_Delete_All_Image_From_Server.Width = Panel1.Width - 20dip"[1/320x480,scale=1]
views.get("btn_delete_all_image_from_server").vw.setWidth((int)((views.get("panel1").vw.getWidth())-(20d * scale)));
//BA.debugLineNum = 29;BA.debugLine="btn_Delete_All_Image_From_Server.Left = Panel1.Left + 10dip"[1/320x480,scale=1]
views.get("btn_delete_all_image_from_server").vw.setLeft((int)((views.get("panel1").vw.getLeft())+(10d * scale)));
//BA.debugLineNum = 31;BA.debugLine="Panel2.Top = btn_Delete_All_Image_From_Server.Bottom + 5dip"[1/320x480,scale=1]
views.get("panel2").vw.setTop((int)((views.get("btn_delete_all_image_from_server").vw.getTop() + views.get("btn_delete_all_image_from_server").vw.getHeight())+(5d * scale)));
//BA.debugLineNum = 32;BA.debugLine="Panel2.Width = Panel1.Width - 20dip"[1/320x480,scale=1]
views.get("panel2").vw.setWidth((int)((views.get("panel1").vw.getWidth())-(20d * scale)));
//BA.debugLineNum = 33;BA.debugLine="Panel2.Left = Panel1.Left + 10dip"[1/320x480,scale=1]
views.get("panel2").vw.setLeft((int)((views.get("panel1").vw.getLeft())+(10d * scale)));
//BA.debugLineNum = 34;BA.debugLine="Image_name.Width = Panel2.Width - 10dip"[1/320x480,scale=1]
views.get("image_name").vw.setWidth((int)((views.get("panel2").vw.getWidth())-(10d * scale)));
//BA.debugLineNum = 36;BA.debugLine="ImageView1.Height = Panel1.Height - (btn_Select_Image.Height + btn_Display_Image_From_Server.Height + Panel2.Height + btn_Delete_All_Image_From_Server.Height + 40dip)"[1/320x480,scale=1]
views.get("imageview1").vw.setHeight((int)((views.get("panel1").vw.getHeight())-((views.get("btn_select_image").vw.getHeight())+(views.get("btn_display_image_from_server").vw.getHeight())+(views.get("panel2").vw.getHeight())+(views.get("btn_delete_all_image_from_server").vw.getHeight())+(40d * scale))));
//BA.debugLineNum = 37;BA.debugLine="ImageView1.Top = Image_name.Bottom + 10dip"[1/320x480,scale=1]
views.get("imageview1").vw.setTop((int)((views.get("image_name").vw.getTop() + views.get("image_name").vw.getHeight())+(10d * scale)));
//BA.debugLineNum = 38;BA.debugLine="ImageView1.Width = Panel1.Width / 2"[1/320x480,scale=1]
views.get("imageview1").vw.setWidth((int)((views.get("panel1").vw.getWidth())/2d));
//BA.debugLineNum = 39;BA.debugLine="ImageView1.Left = Panel1.Left + 10dip"[1/320x480,scale=1]
views.get("imageview1").vw.setLeft((int)((views.get("panel1").vw.getLeft())+(10d * scale)));
//BA.debugLineNum = 40;BA.debugLine="ImageView1.Bottom = Panel1.Bottom - 10dip"[1/320x480,scale=1]
views.get("imageview1").vw.setTop((int)((views.get("panel1").vw.getTop() + views.get("panel1").vw.getHeight())-(10d * scale) - (views.get("imageview1").vw.getHeight())));
//BA.debugLineNum = 42;BA.debugLine="ListView1.Height = ImageView1.Height"[1/320x480,scale=1]
views.get("listview1").vw.setHeight((int)((views.get("imageview1").vw.getHeight())));
//BA.debugLineNum = 43;BA.debugLine="ListView1.Top = ImageView1.Top"[1/320x480,scale=1]
views.get("listview1").vw.setTop((int)((views.get("imageview1").vw.getTop())));
//BA.debugLineNum = 44;BA.debugLine="ListView1.Width = ImageView1.Width - 25dip"[1/320x480,scale=1]
views.get("listview1").vw.setWidth((int)((views.get("imageview1").vw.getWidth())-(25d * scale)));
//BA.debugLineNum = 45;BA.debugLine="ListView1.Left = ImageView1.Right + 5dip"[1/320x480,scale=1]
views.get("listview1").vw.setLeft((int)((views.get("imageview1").vw.getLeft() + views.get("imageview1").vw.getWidth())+(5d * scale)));
//BA.debugLineNum = 46;BA.debugLine="ListView1.Bottom = ImageView1.Bottom"[1/320x480,scale=1]
views.get("listview1").vw.setTop((int)((views.get("imageview1").vw.getTop() + views.get("imageview1").vw.getHeight()) - (views.get("listview1").vw.getHeight())));

}
public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);

}
}