package b4a.example;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = true;
    public static WeakReference<Activity> previousOne;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (isFirst) {
			processBA = new anywheresoftware.b4a.ShellBA(this.getApplicationContext(), null, null, "b4a.example", "b4a.example.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		mostCurrent = this;
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(processBA, wl, true))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "b4a.example", "b4a.example.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "b4a.example.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null) //workaround for emulator bug (Issue 2423)
            return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        processBA.setActivityPaused(true);
        mostCurrent = null;
        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
			if (mostCurrent == null || mostCurrent != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
		    processBA.raiseEvent(mostCurrent._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }



public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        anywheresoftware.b4a.samples.httputils2.httputils2service._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}
public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}

private static BA killProgramHelper(BA ba) {
    if (ba == null)
        return null;
    anywheresoftware.b4a.BA.SharedProcessBA sharedProcessBA = ba.sharedProcessBA;
    if (sharedProcessBA == null || sharedProcessBA.activityBA == null)
        return null;
    return sharedProcessBA.activityBA.get();
}
public static void killProgram() {
     {
            Activity __a = null;
            if (main.previousOne != null) {
				__a = main.previousOne.get();
			}
            else {
                BA ba = killProgramHelper(main.mostCurrent == null ? null : main.mostCurrent.processBA);
                if (ba != null) __a = ba.activity;
            }
            if (__a != null)
				__a.finish();}

BA.applicationContext.stopService(new android.content.Intent(BA.applicationContext, imagedownloader.class));
}
public anywheresoftware.b4a.keywords.Common __c = null;
public static String _serverurl = "";
public static anywheresoftware.b4a.phone.Phone.ContentChooser _chooser = null;
public static anywheresoftware.b4h.okhttp.OkHttpClientWrapper _hc = null;
public static anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn_select_image = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn_resize_image_save_upload = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn_display_image_from_server = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn_delete_image_from_server = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btn_delete_all_image_from_server = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _imageview1 = null;
public anywheresoftware.b4a.objects.EditTextWrapper _image_name = null;
public anywheresoftware.b4a.objects.ListViewWrapper _listview1 = null;
public anywheresoftware.b4a.samples.httputils2.httputils2service _httputils2service = null;
public b4a.example.imagedownloader _imagedownloader = null;
public b4a.example.multipartpost _multipartpost = null;
public static String  _activity_create(boolean _firsttime) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "activity_create"))
	return (String) Debug.delegate(mostCurrent.activityBA, "activity_create", new Object[] {_firsttime});
RDebugUtils.currentLine=262144;
 //BA.debugLineNum = 262144;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
RDebugUtils.currentLine=262145;
 //BA.debugLineNum = 262145;BA.debugLine="Activity.LoadLayout(\"1\")";
mostCurrent._activity.LoadLayout("1",mostCurrent.activityBA);
RDebugUtils.currentLine=262147;
 //BA.debugLineNum = 262147;BA.debugLine="If FirstTime Then";
if (_firsttime) { 
RDebugUtils.currentLine=262148;
 //BA.debugLineNum = 262148;BA.debugLine="hc.Initialize(\"hc\")";
_hc.Initialize("hc");
 };
RDebugUtils.currentLine=262151;
 //BA.debugLineNum = 262151;BA.debugLine="display_list_of_image";
_display_list_of_image();
RDebugUtils.currentLine=262152;
 //BA.debugLineNum = 262152;BA.debugLine="End Sub";
return "";
}
public static String  _display_list_of_image() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "display_list_of_image"))
	return (String) Debug.delegate(mostCurrent.activityBA, "display_list_of_image", null);
anywheresoftware.b4a.samples.httputils2.httpjob _fi = null;
RDebugUtils.currentLine=327680;
 //BA.debugLineNum = 327680;BA.debugLine="Sub display_list_of_image";
RDebugUtils.currentLine=327684;
 //BA.debugLineNum = 327684;BA.debugLine="ListView1.Clear";
mostCurrent._listview1.Clear();
RDebugUtils.currentLine=327686;
 //BA.debugLineNum = 327686;BA.debugLine="Dim fi As HttpJob";
_fi = new anywheresoftware.b4a.samples.httputils2.httpjob();
RDebugUtils.currentLine=327687;
 //BA.debugLineNum = 327687;BA.debugLine="fi.Initialize(\"getfiles\", Me)";
_fi._initialize(processBA,"getfiles",main.getObject());
RDebugUtils.currentLine=327688;
 //BA.debugLineNum = 327688;BA.debugLine="fi.Download2(ServerUrl & \"get_list_images.php\", _";
_fi._download2(_serverurl+"get_list_images.php",new String[]{"Null","Null"});
RDebugUtils.currentLine=327690;
 //BA.debugLineNum = 327690;BA.debugLine="End Sub";
return "";
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=196608;
 //BA.debugLineNum = 196608;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
RDebugUtils.currentLine=196610;
 //BA.debugLineNum = 196610;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "activity_resume"))
	return (String) Debug.delegate(mostCurrent.activityBA, "activity_resume", null);
RDebugUtils.currentLine=131072;
 //BA.debugLineNum = 131072;BA.debugLine="Sub Activity_Resume";
RDebugUtils.currentLine=131074;
 //BA.debugLineNum = 131074;BA.debugLine="End Sub";
return "";
}
public static String  _btn_delete_all_image_from_server_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "btn_delete_all_image_from_server_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "btn_delete_all_image_from_server_click", null);
anywheresoftware.b4a.samples.httputils2.httpjob _job = null;
RDebugUtils.currentLine=917504;
 //BA.debugLineNum = 917504;BA.debugLine="Sub btn_Delete_All_Image_From_Server_Click";
RDebugUtils.currentLine=917505;
 //BA.debugLineNum = 917505;BA.debugLine="Dim job As HttpJob";
_job = new anywheresoftware.b4a.samples.httputils2.httpjob();
RDebugUtils.currentLine=917506;
 //BA.debugLineNum = 917506;BA.debugLine="job.Initialize(\"\", Me)";
_job._initialize(processBA,"",main.getObject());
RDebugUtils.currentLine=917508;
 //BA.debugLineNum = 917508;BA.debugLine="job.PostString(ServerUrl & \"delete_all_image.php\"";
_job._poststring(_serverurl+"delete_all_image.php","");
RDebugUtils.currentLine=917510;
 //BA.debugLineNum = 917510;BA.debugLine="Image_name.Text = \"\"";
mostCurrent._image_name.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=917511;
 //BA.debugLineNum = 917511;BA.debugLine="ImageView1.Bitmap = Null";
mostCurrent._imageview1.setBitmap((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.Null));
RDebugUtils.currentLine=917513;
 //BA.debugLineNum = 917513;BA.debugLine="display_list_of_image";
_display_list_of_image();
RDebugUtils.currentLine=917514;
 //BA.debugLineNum = 917514;BA.debugLine="End Sub";
return "";
}
public static String  _btn_delete_image_from_server_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "btn_delete_image_from_server_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "btn_delete_image_from_server_click", null);
anywheresoftware.b4a.samples.httputils2.httpjob _job = null;
RDebugUtils.currentLine=851968;
 //BA.debugLineNum = 851968;BA.debugLine="Sub btn_Delete_Image_from_Server_Click";
RDebugUtils.currentLine=851969;
 //BA.debugLineNum = 851969;BA.debugLine="If Image_name.Text = \"\" Then";
if ((mostCurrent._image_name.getText()).equals("")) { 
RDebugUtils.currentLine=851970;
 //BA.debugLineNum = 851970;BA.debugLine="Msgbox(\"Write Image Name\",\"Select, Resize, Save,";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("Write Image Name"),BA.ObjectToCharSequence("Select, Resize, Save, Upload, Display, Delete and Delete All Images"),mostCurrent.activityBA);
RDebugUtils.currentLine=851971;
 //BA.debugLineNum = 851971;BA.debugLine="Return";
if (true) return "";
 };
RDebugUtils.currentLine=851974;
 //BA.debugLineNum = 851974;BA.debugLine="Dim job As HttpJob";
_job = new anywheresoftware.b4a.samples.httputils2.httpjob();
RDebugUtils.currentLine=851975;
 //BA.debugLineNum = 851975;BA.debugLine="job.Initialize(\"\", Me)";
_job._initialize(processBA,"",main.getObject());
RDebugUtils.currentLine=851977;
 //BA.debugLineNum = 851977;BA.debugLine="job.PostString(ServerUrl & \"delete_single_image.p";
_job._poststring(_serverurl+"delete_single_image.php?name="+mostCurrent._image_name.getText()+".jpg","");
RDebugUtils.currentLine=851979;
 //BA.debugLineNum = 851979;BA.debugLine="Image_name.Text = \"\"";
mostCurrent._image_name.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=851980;
 //BA.debugLineNum = 851980;BA.debugLine="ImageView1.Bitmap = Null";
mostCurrent._imageview1.setBitmap((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.Null));
RDebugUtils.currentLine=851982;
 //BA.debugLineNum = 851982;BA.debugLine="display_list_of_image";
_display_list_of_image();
RDebugUtils.currentLine=851983;
 //BA.debugLineNum = 851983;BA.debugLine="End Sub";
return "";
}
public static String  _btn_display_image_from_server_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "btn_display_image_from_server_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "btn_display_image_from_server_click", null);
anywheresoftware.b4a.objects.collections.Map _links = null;
RDebugUtils.currentLine=786432;
 //BA.debugLineNum = 786432;BA.debugLine="Sub btn_Display_Image_From_Server_Click";
RDebugUtils.currentLine=786433;
 //BA.debugLineNum = 786433;BA.debugLine="If Image_name.Text = \"\" Then";
if ((mostCurrent._image_name.getText()).equals("")) { 
RDebugUtils.currentLine=786434;
 //BA.debugLineNum = 786434;BA.debugLine="Msgbox(\"Write Image Name\",\"Select, Resize, Save,";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("Write Image Name"),BA.ObjectToCharSequence("Select, Resize, Save, Upload, Display, Delete and Delete All Images"),mostCurrent.activityBA);
RDebugUtils.currentLine=786435;
 //BA.debugLineNum = 786435;BA.debugLine="Return";
if (true) return "";
 };
RDebugUtils.currentLine=786438;
 //BA.debugLineNum = 786438;BA.debugLine="ProgressDialogShow2(\"Fetching Image ...\", False)";
anywheresoftware.b4a.keywords.Common.ProgressDialogShow2(mostCurrent.activityBA,BA.ObjectToCharSequence("Fetching Image ..."),anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=786441;
 //BA.debugLineNum = 786441;BA.debugLine="CallSub(ImageDownloader, \"ClearCache\")";
anywheresoftware.b4a.keywords.Common.CallSubDebug(processBA,(Object)(mostCurrent._imagedownloader.getObject()),"ClearCache");
RDebugUtils.currentLine=786442;
 //BA.debugLineNum = 786442;BA.debugLine="Dim links As Map";
_links = new anywheresoftware.b4a.objects.collections.Map();
RDebugUtils.currentLine=786444;
 //BA.debugLineNum = 786444;BA.debugLine="links.Initialize";
_links.Initialize();
RDebugUtils.currentLine=786445;
 //BA.debugLineNum = 786445;BA.debugLine="links.Put(ImageView1, ServerUrl & \"uploads/\" & Im";
_links.Put((Object)(mostCurrent._imageview1.getObject()),(Object)(_serverurl+"uploads/"+mostCurrent._image_name.getText()+".jpg"));
RDebugUtils.currentLine=786446;
 //BA.debugLineNum = 786446;BA.debugLine="CallSubDelayed2(ImageDownloader, \"Download\", link";
anywheresoftware.b4a.keywords.Common.CallSubDelayed2(processBA,(Object)(mostCurrent._imagedownloader.getObject()),"Download",(Object)(_links));
RDebugUtils.currentLine=786447;
 //BA.debugLineNum = 786447;BA.debugLine="End Sub";
return "";
}
public static String  _btn_resize_image_save_upload_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "btn_resize_image_save_upload_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "btn_resize_image_save_upload_click", null);
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _b = null;
anywheresoftware.b4a.objects.collections.List _files = null;
b4a.example.multipartpost._filedata _fd = null;
anywheresoftware.b4a.objects.collections.Map _nv = null;
anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest _req = null;
RDebugUtils.currentLine=720896;
 //BA.debugLineNum = 720896;BA.debugLine="Sub btn_Resize_Image_Save_Upload_Click";
RDebugUtils.currentLine=720897;
 //BA.debugLineNum = 720897;BA.debugLine="If Image_name.Text = \"\" Then";
if ((mostCurrent._image_name.getText()).equals("")) { 
RDebugUtils.currentLine=720898;
 //BA.debugLineNum = 720898;BA.debugLine="Msgbox(\"Write Image Name\",\"Select, Resize, Save,";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("Write Image Name"),BA.ObjectToCharSequence("Select, Resize, Save, Upload, Display, Delete and Delete All Images"),mostCurrent.activityBA);
RDebugUtils.currentLine=720899;
 //BA.debugLineNum = 720899;BA.debugLine="Return";
if (true) return "";
 };
RDebugUtils.currentLine=720903;
 //BA.debugLineNum = 720903;BA.debugLine="Dim b As Bitmap";
_b = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
RDebugUtils.currentLine=720904;
 //BA.debugLineNum = 720904;BA.debugLine="b = ImageView1.Bitmap";
_b.setObject((android.graphics.Bitmap)(mostCurrent._imageview1.getBitmap()));
RDebugUtils.currentLine=720905;
 //BA.debugLineNum = 720905;BA.debugLine="b = ResizeBitmap(b,300, 300)";
_b = _resizebitmap(_b,(int) (300),(int) (300));
RDebugUtils.currentLine=720906;
 //BA.debugLineNum = 720906;BA.debugLine="out = File.OpenOutput(File.DirDefaultExternal, \"/";
_out = anywheresoftware.b4a.keywords.Common.File.OpenOutput(anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal(),"/"+mostCurrent._image_name.getText()+".jpg",anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=720907;
 //BA.debugLineNum = 720907;BA.debugLine="b.WriteToStream(out, 100, \"JPEG\")";
_b.WriteToStream((java.io.OutputStream)(_out.getObject()),(int) (100),BA.getEnumFromString(android.graphics.Bitmap.CompressFormat.class,"JPEG"));
RDebugUtils.currentLine=720908;
 //BA.debugLineNum = 720908;BA.debugLine="out.Close";
_out.Close();
RDebugUtils.currentLine=720912;
 //BA.debugLineNum = 720912;BA.debugLine="Dim files As List";
_files = new anywheresoftware.b4a.objects.collections.List();
RDebugUtils.currentLine=720913;
 //BA.debugLineNum = 720913;BA.debugLine="files.Initialize";
_files.Initialize();
RDebugUtils.currentLine=720915;
 //BA.debugLineNum = 720915;BA.debugLine="Dim fd As FileData";
_fd = new b4a.example.multipartpost._filedata();
RDebugUtils.currentLine=720916;
 //BA.debugLineNum = 720916;BA.debugLine="fd.Initialize";
_fd.Initialize();
RDebugUtils.currentLine=720917;
 //BA.debugLineNum = 720917;BA.debugLine="fd.Dir = File.DirDefaultExternal & \"/\"";
_fd.Dir = anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal()+"/";
RDebugUtils.currentLine=720918;
 //BA.debugLineNum = 720918;BA.debugLine="fd.FileName = Image_name.Text & \".jpg\"";
_fd.FileName = mostCurrent._image_name.getText()+".jpg";
RDebugUtils.currentLine=720919;
 //BA.debugLineNum = 720919;BA.debugLine="fd.KeyName = \"Aufnahme\"";
_fd.KeyName = "Aufnahme";
RDebugUtils.currentLine=720920;
 //BA.debugLineNum = 720920;BA.debugLine="fd.ContentType = \"application/octet-stream\"";
_fd.ContentType = "application/octet-stream";
RDebugUtils.currentLine=720921;
 //BA.debugLineNum = 720921;BA.debugLine="files.Add(fd)";
_files.Add((Object)(_fd));
RDebugUtils.currentLine=720923;
 //BA.debugLineNum = 720923;BA.debugLine="Dim NV As Map";
_nv = new anywheresoftware.b4a.objects.collections.Map();
RDebugUtils.currentLine=720924;
 //BA.debugLineNum = 720924;BA.debugLine="NV.Initialize";
_nv.Initialize();
RDebugUtils.currentLine=720925;
 //BA.debugLineNum = 720925;BA.debugLine="NV.Put(\"action\", \"upload\")";
_nv.Put((Object)("action"),(Object)("upload"));
RDebugUtils.currentLine=720926;
 //BA.debugLineNum = 720926;BA.debugLine="Dim req As OkHttpRequest";
_req = new anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest();
RDebugUtils.currentLine=720927;
 //BA.debugLineNum = 720927;BA.debugLine="req = MultipartPost.CreatePostRequest(ServerUrl &";
_req = mostCurrent._multipartpost._createpostrequest(mostCurrent.activityBA,_serverurl+"multipartpost.php",_nv,_files);
RDebugUtils.currentLine=720928;
 //BA.debugLineNum = 720928;BA.debugLine="hc.Execute(req, 1)";
_hc.Execute(processBA,_req,(int) (1));
RDebugUtils.currentLine=720930;
 //BA.debugLineNum = 720930;BA.debugLine="Image_name.Text = \"\"";
mostCurrent._image_name.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=720931;
 //BA.debugLineNum = 720931;BA.debugLine="ImageView1.Bitmap = Null";
mostCurrent._imageview1.setBitmap((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.Null));
RDebugUtils.currentLine=720933;
 //BA.debugLineNum = 720933;BA.debugLine="display_list_of_image";
_display_list_of_image();
RDebugUtils.currentLine=720934;
 //BA.debugLineNum = 720934;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper  _resizebitmap(anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _original,int _width,int _height) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "resizebitmap"))
	return (anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper) Debug.delegate(mostCurrent.activityBA, "resizebitmap", new Object[] {_original,_width,_height});
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _new = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper _c = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper _destrect = null;
RDebugUtils.currentLine=655360;
 //BA.debugLineNum = 655360;BA.debugLine="Sub ResizeBitmap(original As Bitmap, width As Int,";
RDebugUtils.currentLine=655361;
 //BA.debugLineNum = 655361;BA.debugLine="Dim new As Bitmap";
_new = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
RDebugUtils.currentLine=655362;
 //BA.debugLineNum = 655362;BA.debugLine="new.InitializeMutable(width, height)";
_new.InitializeMutable(_width,_height);
RDebugUtils.currentLine=655363;
 //BA.debugLineNum = 655363;BA.debugLine="Dim c As Canvas";
_c = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
RDebugUtils.currentLine=655364;
 //BA.debugLineNum = 655364;BA.debugLine="c.Initialize2(new)";
_c.Initialize2((android.graphics.Bitmap)(_new.getObject()));
RDebugUtils.currentLine=655365;
 //BA.debugLineNum = 655365;BA.debugLine="Dim destRect As Rect";
_destrect = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper();
RDebugUtils.currentLine=655366;
 //BA.debugLineNum = 655366;BA.debugLine="destRect.Initialize(0, 0, width, height)";
_destrect.Initialize((int) (0),(int) (0),_width,_height);
RDebugUtils.currentLine=655367;
 //BA.debugLineNum = 655367;BA.debugLine="c.DrawBitmap(original, Null, destRect)";
_c.DrawBitmap((android.graphics.Bitmap)(_original.getObject()),(android.graphics.Rect)(anywheresoftware.b4a.keywords.Common.Null),(android.graphics.Rect)(_destrect.getObject()));
RDebugUtils.currentLine=655368;
 //BA.debugLineNum = 655368;BA.debugLine="Return new";
if (true) return _new;
RDebugUtils.currentLine=655369;
 //BA.debugLineNum = 655369;BA.debugLine="End Sub";
return null;
}
public static String  _btn_select_image_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "btn_select_image_click"))
	return (String) Debug.delegate(mostCurrent.activityBA, "btn_select_image_click", null);
RDebugUtils.currentLine=589824;
 //BA.debugLineNum = 589824;BA.debugLine="Sub btn_Select_Image_Click";
RDebugUtils.currentLine=589825;
 //BA.debugLineNum = 589825;BA.debugLine="If Chooser.IsInitialized = False Then";
if (_chooser.IsInitialized()==anywheresoftware.b4a.keywords.Common.False) { 
RDebugUtils.currentLine=589826;
 //BA.debugLineNum = 589826;BA.debugLine="Chooser.Initialize(\"chooser\")";
_chooser.Initialize("chooser");
 };
RDebugUtils.currentLine=589828;
 //BA.debugLineNum = 589828;BA.debugLine="Chooser.Show(\"image/*\", \"Choose image\")";
_chooser.Show(processBA,"image/*","Choose image");
RDebugUtils.currentLine=589829;
 //BA.debugLineNum = 589829;BA.debugLine="End Sub";
return "";
}
public static String  _chooser_result(boolean _success,String _dir,String _filename) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "chooser_result"))
	return (String) Debug.delegate(mostCurrent.activityBA, "chooser_result", new Object[] {_success,_dir,_filename});
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _b = null;
RDebugUtils.currentLine=524288;
 //BA.debugLineNum = 524288;BA.debugLine="Sub chooser_Result(Success As Boolean, Dir As Stri";
RDebugUtils.currentLine=524289;
 //BA.debugLineNum = 524289;BA.debugLine="If Success Then";
if (_success) { 
RDebugUtils.currentLine=524290;
 //BA.debugLineNum = 524290;BA.debugLine="Dim b As Bitmap";
_b = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
RDebugUtils.currentLine=524291;
 //BA.debugLineNum = 524291;BA.debugLine="b = LoadBitmap(Dir, FileName)";
_b = anywheresoftware.b4a.keywords.Common.LoadBitmap(_dir,_filename);
RDebugUtils.currentLine=524292;
 //BA.debugLineNum = 524292;BA.debugLine="ImageView1.Bitmap = b";
mostCurrent._imageview1.setBitmap((android.graphics.Bitmap)(_b.getObject()));
 }else {
RDebugUtils.currentLine=524294;
 //BA.debugLineNum = 524294;BA.debugLine="ToastMessageShow(\"No image selected\", True)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("No image selected"),anywheresoftware.b4a.keywords.Common.True);
 };
RDebugUtils.currentLine=524296;
 //BA.debugLineNum = 524296;BA.debugLine="End Sub";
return "";
}
public static String  _hc_responsesuccess(anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpResponse _response,int _taskid) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "hc_responsesuccess"))
	return (String) Debug.delegate(mostCurrent.activityBA, "hc_responsesuccess", new Object[] {_response,_taskid});
RDebugUtils.currentLine=393216;
 //BA.debugLineNum = 393216;BA.debugLine="Sub hc_ResponseSuccess (Response As OkHttpResponse";
RDebugUtils.currentLine=393217;
 //BA.debugLineNum = 393217;BA.debugLine="out.InitializeToBytesArray(0) ' I expect less tha";
_out.InitializeToBytesArray((int) (0));
RDebugUtils.currentLine=393218;
 //BA.debugLineNum = 393218;BA.debugLine="Response.GetAsynchronously(\"Response\", out, True,";
_response.GetAsynchronously(processBA,"Response",(java.io.OutputStream)(_out.getObject()),anywheresoftware.b4a.keywords.Common.True,_taskid);
RDebugUtils.currentLine=393219;
 //BA.debugLineNum = 393219;BA.debugLine="End Sub";
return "";
}
public static String  _jobdone(anywheresoftware.b4a.samples.httputils2.httpjob _job) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "jobdone"))
	return (String) Debug.delegate(mostCurrent.activityBA, "jobdone", new Object[] {_job});
String _res = "";
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.List _listoffiles = null;
int _i = 0;
RDebugUtils.currentLine=1048576;
 //BA.debugLineNum = 1048576;BA.debugLine="Sub JobDone(Job As HttpJob)";
RDebugUtils.currentLine=1048578;
 //BA.debugLineNum = 1048578;BA.debugLine="If Job.Success Then";
if (_job._success) { 
RDebugUtils.currentLine=1048579;
 //BA.debugLineNum = 1048579;BA.debugLine="Dim res As String";
_res = "";
RDebugUtils.currentLine=1048580;
 //BA.debugLineNum = 1048580;BA.debugLine="res = Job.GetString";
_res = _job._getstring();
RDebugUtils.currentLine=1048581;
 //BA.debugLineNum = 1048581;BA.debugLine="Log(\"Back from Job:\" & Job.JobName )";
anywheresoftware.b4a.keywords.Common.Log("Back from Job:"+_job._jobname);
RDebugUtils.currentLine=1048582;
 //BA.debugLineNum = 1048582;BA.debugLine="Log(\"Response from server: \" & res)";
anywheresoftware.b4a.keywords.Common.Log("Response from server: "+_res);
RDebugUtils.currentLine=1048584;
 //BA.debugLineNum = 1048584;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
RDebugUtils.currentLine=1048585;
 //BA.debugLineNum = 1048585;BA.debugLine="parser.Initialize(res)";
_parser.Initialize(_res);
RDebugUtils.currentLine=1048587;
 //BA.debugLineNum = 1048587;BA.debugLine="Select Job.JobName";
switch (BA.switchObjectToInt(_job._jobname,"getfiles")) {
case 0: {
RDebugUtils.currentLine=1048590;
 //BA.debugLineNum = 1048590;BA.debugLine="Dim ListOfFiles As List";
_listoffiles = new anywheresoftware.b4a.objects.collections.List();
RDebugUtils.currentLine=1048591;
 //BA.debugLineNum = 1048591;BA.debugLine="ListOfFiles = parser.NextArray";
_listoffiles = _parser.NextArray();
RDebugUtils.currentLine=1048592;
 //BA.debugLineNum = 1048592;BA.debugLine="If ListOfFiles.Size > 0 Then";
if (_listoffiles.getSize()>0) { 
RDebugUtils.currentLine=1048593;
 //BA.debugLineNum = 1048593;BA.debugLine="For i = 0 To ListOfFiles.Size - 1";
{
final int step13 = 1;
final int limit13 = (int) (_listoffiles.getSize()-1);
_i = (int) (0) ;
for (;(step13 > 0 && _i <= limit13) || (step13 < 0 && _i >= limit13) ;_i = ((int)(0 + _i + step13))  ) {
RDebugUtils.currentLine=1048595;
 //BA.debugLineNum = 1048595;BA.debugLine="ListView1.AddSingleLine(ListOfFiles.Get(i))";
mostCurrent._listview1.AddSingleLine(BA.ObjectToCharSequence(_listoffiles.Get(_i)));
 }
};
 };
 break; }
}
;
 }else {
RDebugUtils.currentLine=1048601;
 //BA.debugLineNum = 1048601;BA.debugLine="ToastMessageShow(\"Error: \" & Job.ErrorMessage, Fa";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Error: "+_job._errormessage),anywheresoftware.b4a.keywords.Common.False);
 };
RDebugUtils.currentLine=1048604;
 //BA.debugLineNum = 1048604;BA.debugLine="Job.Release";
_job._release();
RDebugUtils.currentLine=1048605;
 //BA.debugLineNum = 1048605;BA.debugLine="End Sub";
return "";
}
public static String  _listview1_itemclick(int _position,Object _value) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "listview1_itemclick"))
	return (String) Debug.delegate(mostCurrent.activityBA, "listview1_itemclick", new Object[] {_position,_value});
anywheresoftware.b4a.objects.collections.Map _links = null;
RDebugUtils.currentLine=983040;
 //BA.debugLineNum = 983040;BA.debugLine="Sub ListView1_ItemClick (Position As Int, Value As";
RDebugUtils.currentLine=983041;
 //BA.debugLineNum = 983041;BA.debugLine="ProgressDialogShow2(\"Fetching Image ...\", False)";
anywheresoftware.b4a.keywords.Common.ProgressDialogShow2(mostCurrent.activityBA,BA.ObjectToCharSequence("Fetching Image ..."),anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=983044;
 //BA.debugLineNum = 983044;BA.debugLine="CallSub(ImageDownloader, \"ClearCache\")";
anywheresoftware.b4a.keywords.Common.CallSubDebug(processBA,(Object)(mostCurrent._imagedownloader.getObject()),"ClearCache");
RDebugUtils.currentLine=983045;
 //BA.debugLineNum = 983045;BA.debugLine="Dim links As Map";
_links = new anywheresoftware.b4a.objects.collections.Map();
RDebugUtils.currentLine=983047;
 //BA.debugLineNum = 983047;BA.debugLine="links.Initialize";
_links.Initialize();
RDebugUtils.currentLine=983048;
 //BA.debugLineNum = 983048;BA.debugLine="links.Put(ImageView1, ServerUrl & \"uploads/\" & Va";
_links.Put((Object)(mostCurrent._imageview1.getObject()),(Object)(_serverurl+"uploads/"+BA.ObjectToString(_value)));
RDebugUtils.currentLine=983049;
 //BA.debugLineNum = 983049;BA.debugLine="CallSubDelayed2(ImageDownloader, \"Download\", link";
anywheresoftware.b4a.keywords.Common.CallSubDelayed2(processBA,(Object)(mostCurrent._imagedownloader.getObject()),"Download",(Object)(_links));
RDebugUtils.currentLine=983050;
 //BA.debugLineNum = 983050;BA.debugLine="End Sub";
return "";
}
public static String  _response_streamfinish(boolean _success,int _taskid) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "response_streamfinish"))
	return (String) Debug.delegate(mostCurrent.activityBA, "response_streamfinish", new Object[] {_success,_taskid});
byte[] _another_buffer = null;
RDebugUtils.currentLine=458752;
 //BA.debugLineNum = 458752;BA.debugLine="Sub Response_StreamFinish (Success As Boolean, Tas";
RDebugUtils.currentLine=458753;
 //BA.debugLineNum = 458753;BA.debugLine="Dim another_buffer () As Byte";
_another_buffer = new byte[(int) (0)];
;
RDebugUtils.currentLine=458754;
 //BA.debugLineNum = 458754;BA.debugLine="another_buffer = out.ToBytesArray";
_another_buffer = _out.ToBytesArray();
RDebugUtils.currentLine=458755;
 //BA.debugLineNum = 458755;BA.debugLine="Log (BytesToString(another_buffer, 0, another_buf";
anywheresoftware.b4a.keywords.Common.Log(anywheresoftware.b4a.keywords.Common.BytesToString(_another_buffer,(int) (0),_another_buffer.length,"UTF8"));
RDebugUtils.currentLine=458756;
 //BA.debugLineNum = 458756;BA.debugLine="End Sub";
return "";
}
}