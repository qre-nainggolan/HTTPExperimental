package b4a.example;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,44);
if (RapidSub.canDelegate("activity_create")) return b4a.example.main.remoteMe.runUserSub(false, "main","activity_create", _firsttime);
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 44;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(2048);
 BA.debugLineNum = 45;BA.debugLine="Activity.LoadLayout(\"1\")";
Debug.ShouldStop(4096);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("1")),main.mostCurrent.activityBA);
 BA.debugLineNum = 47;BA.debugLine="If FirstTime Then";
Debug.ShouldStop(16384);
if (_firsttime.<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 48;BA.debugLine="hc.Initialize(\"hc\")";
Debug.ShouldStop(32768);
main._hc.runVoidMethod ("Initialize",(Object)(RemoteObject.createImmutable("hc")));
 };
 BA.debugLineNum = 51;BA.debugLine="display_list_of_image";
Debug.ShouldStop(262144);
_display_list_of_image();
 BA.debugLineNum = 52;BA.debugLine="End Sub";
Debug.ShouldStop(524288);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,40);
if (RapidSub.canDelegate("activity_pause")) return b4a.example.main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 40;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(128);
 BA.debugLineNum = 42;BA.debugLine="End Sub";
Debug.ShouldStop(512);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,36);
if (RapidSub.canDelegate("activity_resume")) return b4a.example.main.remoteMe.runUserSub(false, "main","activity_resume");
 BA.debugLineNum = 36;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(8);
 BA.debugLineNum = 38;BA.debugLine="End Sub";
Debug.ShouldStop(32);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btn_delete_all_image_from_server_click() throws Exception{
try {
		Debug.PushSubsStack("btn_Delete_All_Image_From_Server_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,179);
if (RapidSub.canDelegate("btn_delete_all_image_from_server_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","btn_delete_all_image_from_server_click");
RemoteObject _job = RemoteObject.declareNull("anywheresoftware.b4a.samples.httputils2.httpjob");
 BA.debugLineNum = 179;BA.debugLine="Sub btn_Delete_All_Image_From_Server_Click";
Debug.ShouldStop(262144);
 BA.debugLineNum = 180;BA.debugLine="Dim job As HttpJob";
Debug.ShouldStop(524288);
_job = RemoteObject.createNew ("anywheresoftware.b4a.samples.httputils2.httpjob");Debug.locals.put("job", _job);
 BA.debugLineNum = 181;BA.debugLine="job.Initialize(\"\", Me)";
Debug.ShouldStop(1048576);
_job.runVoidMethod ("_initialize",main.processBA,(Object)(BA.ObjectToString("")),(Object)(main.getObject()));
 BA.debugLineNum = 183;BA.debugLine="job.PostString(ServerUrl & \"delete_all_image.php\"";
Debug.ShouldStop(4194304);
_job.runVoidMethod ("_poststring",(Object)(RemoteObject.concat(main._serverurl,RemoteObject.createImmutable("delete_all_image.php"))),(Object)(RemoteObject.createImmutable("")));
 BA.debugLineNum = 185;BA.debugLine="Image_name.Text = \"\"";
Debug.ShouldStop(16777216);
main.mostCurrent._image_name.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 186;BA.debugLine="ImageView1.Bitmap = Null";
Debug.ShouldStop(33554432);
main.mostCurrent._imageview1.runMethod(false,"setBitmap",(main.mostCurrent.__c.getField(false,"Null")));
 BA.debugLineNum = 188;BA.debugLine="display_list_of_image";
Debug.ShouldStop(134217728);
_display_list_of_image();
 BA.debugLineNum = 189;BA.debugLine="End Sub";
Debug.ShouldStop(268435456);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btn_delete_image_from_server_click() throws Exception{
try {
		Debug.PushSubsStack("btn_Delete_Image_from_Server_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,162);
if (RapidSub.canDelegate("btn_delete_image_from_server_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","btn_delete_image_from_server_click");
RemoteObject _job = RemoteObject.declareNull("anywheresoftware.b4a.samples.httputils2.httpjob");
 BA.debugLineNum = 162;BA.debugLine="Sub btn_Delete_Image_from_Server_Click";
Debug.ShouldStop(2);
 BA.debugLineNum = 163;BA.debugLine="If Image_name.Text = \"\" Then";
Debug.ShouldStop(4);
if (RemoteObject.solveBoolean("=",main.mostCurrent._image_name.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 164;BA.debugLine="Msgbox(\"Write Image Name\",\"Select, Resize, Save,";
Debug.ShouldStop(8);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("Write Image Name")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Select, Resize, Save, Upload, Display, Delete and Delete All Images"))),main.mostCurrent.activityBA);
 BA.debugLineNum = 165;BA.debugLine="Return";
Debug.ShouldStop(16);
if (true) return RemoteObject.createImmutable("");
 };
 BA.debugLineNum = 168;BA.debugLine="Dim job As HttpJob";
Debug.ShouldStop(128);
_job = RemoteObject.createNew ("anywheresoftware.b4a.samples.httputils2.httpjob");Debug.locals.put("job", _job);
 BA.debugLineNum = 169;BA.debugLine="job.Initialize(\"\", Me)";
Debug.ShouldStop(256);
_job.runVoidMethod ("_initialize",main.processBA,(Object)(BA.ObjectToString("")),(Object)(main.getObject()));
 BA.debugLineNum = 171;BA.debugLine="job.PostString(ServerUrl & \"delete_single_image.p";
Debug.ShouldStop(1024);
_job.runVoidMethod ("_poststring",(Object)(RemoteObject.concat(main._serverurl,RemoteObject.createImmutable("delete_single_image.php?name="),main.mostCurrent._image_name.runMethod(true,"getText"),RemoteObject.createImmutable(".jpg"))),(Object)(RemoteObject.createImmutable("")));
 BA.debugLineNum = 173;BA.debugLine="Image_name.Text = \"\"";
Debug.ShouldStop(4096);
main.mostCurrent._image_name.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 174;BA.debugLine="ImageView1.Bitmap = Null";
Debug.ShouldStop(8192);
main.mostCurrent._imageview1.runMethod(false,"setBitmap",(main.mostCurrent.__c.getField(false,"Null")));
 BA.debugLineNum = 176;BA.debugLine="display_list_of_image";
Debug.ShouldStop(32768);
_display_list_of_image();
 BA.debugLineNum = 177;BA.debugLine="End Sub";
Debug.ShouldStop(65536);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btn_display_image_from_server_click() throws Exception{
try {
		Debug.PushSubsStack("btn_Display_Image_From_Server_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,145);
if (RapidSub.canDelegate("btn_display_image_from_server_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","btn_display_image_from_server_click");
RemoteObject _links = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.Map");
 BA.debugLineNum = 145;BA.debugLine="Sub btn_Display_Image_From_Server_Click";
Debug.ShouldStop(65536);
 BA.debugLineNum = 146;BA.debugLine="If Image_name.Text = \"\" Then";
Debug.ShouldStop(131072);
if (RemoteObject.solveBoolean("=",main.mostCurrent._image_name.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 147;BA.debugLine="Msgbox(\"Write Image Name\",\"Select, Resize, Save,";
Debug.ShouldStop(262144);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("Write Image Name")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Select, Resize, Save, Upload, Display, Delete and Delete All Images"))),main.mostCurrent.activityBA);
 BA.debugLineNum = 148;BA.debugLine="Return";
Debug.ShouldStop(524288);
if (true) return RemoteObject.createImmutable("");
 };
 BA.debugLineNum = 151;BA.debugLine="ProgressDialogShow2(\"Fetching Image ...\", False)";
Debug.ShouldStop(4194304);
main.mostCurrent.__c.runVoidMethod ("ProgressDialogShow2",main.mostCurrent.activityBA,(Object)(BA.ObjectToCharSequence("Fetching Image ...")),(Object)(main.mostCurrent.__c.getField(true,"False")));
 BA.debugLineNum = 154;BA.debugLine="CallSub(ImageDownloader, \"ClearCache\")";
Debug.ShouldStop(33554432);
main.mostCurrent.__c.runMethodAndSync(false,"CallSubNew",main.processBA,(Object)((main.mostCurrent._imagedownloader.getObject())),(Object)(RemoteObject.createImmutable("ClearCache")));
 BA.debugLineNum = 155;BA.debugLine="Dim links As Map";
Debug.ShouldStop(67108864);
_links = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.Map");Debug.locals.put("links", _links);
 BA.debugLineNum = 157;BA.debugLine="links.Initialize";
Debug.ShouldStop(268435456);
_links.runVoidMethod ("Initialize");
 BA.debugLineNum = 158;BA.debugLine="links.Put(ImageView1, ServerUrl & \"uploads/\" & Im";
Debug.ShouldStop(536870912);
_links.runVoidMethod ("Put",(Object)((main.mostCurrent._imageview1.getObject())),(Object)((RemoteObject.concat(main._serverurl,RemoteObject.createImmutable("uploads/"),main.mostCurrent._image_name.runMethod(true,"getText"),RemoteObject.createImmutable(".jpg")))));
 BA.debugLineNum = 159;BA.debugLine="CallSubDelayed2(ImageDownloader, \"Download\", link";
Debug.ShouldStop(1073741824);
main.mostCurrent.__c.runVoidMethod ("CallSubDelayed2",main.processBA,(Object)((main.mostCurrent._imagedownloader.getObject())),(Object)(BA.ObjectToString("Download")),(Object)((_links)));
 BA.debugLineNum = 160;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btn_resize_image_save_upload_click() throws Exception{
try {
		Debug.PushSubsStack("btn_Resize_Image_Save_Upload_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,105);
if (RapidSub.canDelegate("btn_resize_image_save_upload_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","btn_resize_image_save_upload_click");
RemoteObject _b = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");
RemoteObject _files = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _fd = RemoteObject.declareNull("b4a.example.multipartpost._filedata");
RemoteObject _nv = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.Map");
RemoteObject _req = RemoteObject.declareNull("anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest");
 BA.debugLineNum = 105;BA.debugLine="Sub btn_Resize_Image_Save_Upload_Click";
Debug.ShouldStop(256);
 BA.debugLineNum = 106;BA.debugLine="If Image_name.Text = \"\" Then";
Debug.ShouldStop(512);
if (RemoteObject.solveBoolean("=",main.mostCurrent._image_name.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 107;BA.debugLine="Msgbox(\"Write Image Name\",\"Select, Resize, Save,";
Debug.ShouldStop(1024);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("Write Image Name")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Select, Resize, Save, Upload, Display, Delete and Delete All Images"))),main.mostCurrent.activityBA);
 BA.debugLineNum = 108;BA.debugLine="Return";
Debug.ShouldStop(2048);
if (true) return RemoteObject.createImmutable("");
 };
 BA.debugLineNum = 112;BA.debugLine="Dim b As Bitmap";
Debug.ShouldStop(32768);
_b = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");Debug.locals.put("b", _b);
 BA.debugLineNum = 113;BA.debugLine="b = ImageView1.Bitmap";
Debug.ShouldStop(65536);
_b.setObject(main.mostCurrent._imageview1.runMethod(false,"getBitmap"));
 BA.debugLineNum = 114;BA.debugLine="b = ResizeBitmap(b,300, 300)";
Debug.ShouldStop(131072);
_b = _resizebitmap(_b,BA.numberCast(int.class, 300),BA.numberCast(int.class, 300));Debug.locals.put("b", _b);
 BA.debugLineNum = 115;BA.debugLine="out = File.OpenOutput(File.DirDefaultExternal, \"/";
Debug.ShouldStop(262144);
main._out = main.mostCurrent.__c.getField(false,"File").runMethod(false,"OpenOutput",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirDefaultExternal")),(Object)(RemoteObject.concat(RemoteObject.createImmutable("/"),main.mostCurrent._image_name.runMethod(true,"getText"),RemoteObject.createImmutable(".jpg"))),(Object)(main.mostCurrent.__c.getField(true,"False")));
 BA.debugLineNum = 116;BA.debugLine="b.WriteToStream(out, 100, \"JPEG\")";
Debug.ShouldStop(524288);
_b.runVoidMethod ("WriteToStream",(Object)((main._out.getObject())),(Object)(BA.numberCast(int.class, 100)),(Object)(BA.getEnumFromString(BA.getDeviceClass("android.graphics.Bitmap.CompressFormat"),RemoteObject.createImmutable("JPEG"))));
 BA.debugLineNum = 117;BA.debugLine="out.Close";
Debug.ShouldStop(1048576);
main._out.runVoidMethod ("Close");
 BA.debugLineNum = 121;BA.debugLine="Dim files As List";
Debug.ShouldStop(16777216);
_files = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");Debug.locals.put("files", _files);
 BA.debugLineNum = 122;BA.debugLine="files.Initialize";
Debug.ShouldStop(33554432);
_files.runVoidMethod ("Initialize");
 BA.debugLineNum = 124;BA.debugLine="Dim fd As FileData";
Debug.ShouldStop(134217728);
_fd = RemoteObject.createNew ("b4a.example.multipartpost._filedata");Debug.locals.put("fd", _fd);
 BA.debugLineNum = 125;BA.debugLine="fd.Initialize";
Debug.ShouldStop(268435456);
_fd.runVoidMethod ("Initialize");
 BA.debugLineNum = 126;BA.debugLine="fd.Dir = File.DirDefaultExternal & \"/\"";
Debug.ShouldStop(536870912);
_fd.setField ("Dir",RemoteObject.concat(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirDefaultExternal"),RemoteObject.createImmutable("/")));
 BA.debugLineNum = 127;BA.debugLine="fd.FileName = Image_name.Text & \".jpg\"";
Debug.ShouldStop(1073741824);
_fd.setField ("FileName",RemoteObject.concat(main.mostCurrent._image_name.runMethod(true,"getText"),RemoteObject.createImmutable(".jpg")));
 BA.debugLineNum = 128;BA.debugLine="fd.KeyName = \"Aufnahme\"";
Debug.ShouldStop(-2147483648);
_fd.setField ("KeyName",BA.ObjectToString("Aufnahme"));
 BA.debugLineNum = 129;BA.debugLine="fd.ContentType = \"application/octet-stream\"";
Debug.ShouldStop(1);
_fd.setField ("ContentType",BA.ObjectToString("application/octet-stream"));
 BA.debugLineNum = 130;BA.debugLine="files.Add(fd)";
Debug.ShouldStop(2);
_files.runVoidMethod ("Add",(Object)((_fd)));
 BA.debugLineNum = 132;BA.debugLine="Dim NV As Map";
Debug.ShouldStop(8);
_nv = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.Map");Debug.locals.put("NV", _nv);
 BA.debugLineNum = 133;BA.debugLine="NV.Initialize";
Debug.ShouldStop(16);
_nv.runVoidMethod ("Initialize");
 BA.debugLineNum = 134;BA.debugLine="NV.Put(\"action\", \"upload\")";
Debug.ShouldStop(32);
_nv.runVoidMethod ("Put",(Object)(RemoteObject.createImmutable(("action"))),(Object)((RemoteObject.createImmutable("upload"))));
 BA.debugLineNum = 135;BA.debugLine="Dim req As OkHttpRequest";
Debug.ShouldStop(64);
_req = RemoteObject.createNew ("anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest");Debug.locals.put("req", _req);
 BA.debugLineNum = 136;BA.debugLine="req = MultipartPost.CreatePostRequest(ServerUrl &";
Debug.ShouldStop(128);
_req = main.mostCurrent._multipartpost.runMethod(false,"_createpostrequest",main.mostCurrent.activityBA,(Object)(RemoteObject.concat(main._serverurl,RemoteObject.createImmutable("multipartpost.php"))),(Object)(_nv),(Object)(_files));Debug.locals.put("req", _req);
 BA.debugLineNum = 137;BA.debugLine="hc.Execute(req, 1)";
Debug.ShouldStop(256);
main._hc.runVoidMethod ("Execute",main.processBA,(Object)(_req),(Object)(BA.numberCast(int.class, 1)));
 BA.debugLineNum = 139;BA.debugLine="Image_name.Text = \"\"";
Debug.ShouldStop(1024);
main.mostCurrent._image_name.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 140;BA.debugLine="ImageView1.Bitmap = Null";
Debug.ShouldStop(2048);
main.mostCurrent._imageview1.runMethod(false,"setBitmap",(main.mostCurrent.__c.getField(false,"Null")));
 BA.debugLineNum = 142;BA.debugLine="display_list_of_image";
Debug.ShouldStop(8192);
_display_list_of_image();
 BA.debugLineNum = 143;BA.debugLine="End Sub";
Debug.ShouldStop(16384);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btn_select_image_click() throws Exception{
try {
		Debug.PushSubsStack("btn_Select_Image_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,87);
if (RapidSub.canDelegate("btn_select_image_click")) return b4a.example.main.remoteMe.runUserSub(false, "main","btn_select_image_click");
 BA.debugLineNum = 87;BA.debugLine="Sub btn_Select_Image_Click";
Debug.ShouldStop(4194304);
 BA.debugLineNum = 88;BA.debugLine="If Chooser.IsInitialized = False Then";
Debug.ShouldStop(8388608);
if (RemoteObject.solveBoolean("=",main._chooser.runMethod(true,"IsInitialized"),main.mostCurrent.__c.getField(true,"False"))) { 
 BA.debugLineNum = 89;BA.debugLine="Chooser.Initialize(\"chooser\")";
Debug.ShouldStop(16777216);
main._chooser.runVoidMethod ("Initialize",(Object)(RemoteObject.createImmutable("chooser")));
 };
 BA.debugLineNum = 91;BA.debugLine="Chooser.Show(\"image/*\", \"Choose image\")";
Debug.ShouldStop(67108864);
main._chooser.runVoidMethod ("Show",main.processBA,(Object)(BA.ObjectToString("image/*")),(Object)(RemoteObject.createImmutable("Choose image")));
 BA.debugLineNum = 92;BA.debugLine="End Sub";
Debug.ShouldStop(134217728);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _chooser_result(RemoteObject _success,RemoteObject _dir,RemoteObject _filename) throws Exception{
try {
		Debug.PushSubsStack("chooser_Result (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,77);
if (RapidSub.canDelegate("chooser_result")) return b4a.example.main.remoteMe.runUserSub(false, "main","chooser_result", _success, _dir, _filename);
RemoteObject _b = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");
Debug.locals.put("Success", _success);
Debug.locals.put("Dir", _dir);
Debug.locals.put("FileName", _filename);
 BA.debugLineNum = 77;BA.debugLine="Sub chooser_Result(Success As Boolean, Dir As Stri";
Debug.ShouldStop(4096);
 BA.debugLineNum = 78;BA.debugLine="If Success Then";
Debug.ShouldStop(8192);
if (_success.<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 79;BA.debugLine="Dim b As Bitmap";
Debug.ShouldStop(16384);
_b = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");Debug.locals.put("b", _b);
 BA.debugLineNum = 80;BA.debugLine="b = LoadBitmap(Dir, FileName)";
Debug.ShouldStop(32768);
_b = main.mostCurrent.__c.runMethod(false,"LoadBitmap",(Object)(_dir),(Object)(_filename));Debug.locals.put("b", _b);
 BA.debugLineNum = 81;BA.debugLine="ImageView1.Bitmap = b";
Debug.ShouldStop(65536);
main.mostCurrent._imageview1.runMethod(false,"setBitmap",(_b.getObject()));
 }else {
 BA.debugLineNum = 83;BA.debugLine="ToastMessageShow(\"No image selected\", True)";
Debug.ShouldStop(262144);
main.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("No image selected")),(Object)(main.mostCurrent.__c.getField(true,"True")));
 };
 BA.debugLineNum = 85;BA.debugLine="End Sub";
Debug.ShouldStop(1048576);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _display_list_of_image() throws Exception{
try {
		Debug.PushSubsStack("display_list_of_image (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,54);
if (RapidSub.canDelegate("display_list_of_image")) return b4a.example.main.remoteMe.runUserSub(false, "main","display_list_of_image");
RemoteObject _fi = RemoteObject.declareNull("anywheresoftware.b4a.samples.httputils2.httpjob");
 BA.debugLineNum = 54;BA.debugLine="Sub display_list_of_image";
Debug.ShouldStop(2097152);
 BA.debugLineNum = 58;BA.debugLine="ListView1.Clear";
Debug.ShouldStop(33554432);
main.mostCurrent._listview1.runVoidMethod ("Clear");
 BA.debugLineNum = 60;BA.debugLine="Dim fi As HttpJob";
Debug.ShouldStop(134217728);
_fi = RemoteObject.createNew ("anywheresoftware.b4a.samples.httputils2.httpjob");Debug.locals.put("fi", _fi);
 BA.debugLineNum = 61;BA.debugLine="fi.Initialize(\"getfiles\", Me)";
Debug.ShouldStop(268435456);
_fi.runVoidMethod ("_initialize",main.processBA,(Object)(BA.ObjectToString("getfiles")),(Object)(main.getObject()));
 BA.debugLineNum = 62;BA.debugLine="fi.Download2(ServerUrl & \"get_list_images.php\", _";
Debug.ShouldStop(536870912);
_fi.runVoidMethod ("_download2",(Object)(RemoteObject.concat(main._serverurl,RemoteObject.createImmutable("get_list_images.php"))),(Object)(RemoteObject.createNewArray("String",new int[] {2},new Object[] {BA.ObjectToString("Null"),RemoteObject.createImmutable("Null")})));
 BA.debugLineNum = 64;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 24;BA.debugLine="Private btn_Select_Image As Button";
main.mostCurrent._btn_select_image = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 25;BA.debugLine="Private btn_Resize_Image_Save_Upload As Button";
main.mostCurrent._btn_resize_image_save_upload = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 26;BA.debugLine="Private btn_Display_Image_From_Server As Button";
main.mostCurrent._btn_display_image_from_server = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 27;BA.debugLine="Private btn_Delete_Image_from_Server As Button";
main.mostCurrent._btn_delete_image_from_server = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 28;BA.debugLine="Private btn_Delete_All_Image_From_Server As Butto";
main.mostCurrent._btn_delete_all_image_from_server = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 30;BA.debugLine="Private ImageView1 As ImageView";
main.mostCurrent._imageview1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ImageViewWrapper");
 //BA.debugLineNum = 32;BA.debugLine="Private Image_name As EditText";
main.mostCurrent._image_name = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 33;BA.debugLine="Private ListView1 As ListView";
main.mostCurrent._listview1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ListViewWrapper");
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _hc_responsesuccess(RemoteObject _response,RemoteObject _taskid) throws Exception{
try {
		Debug.PushSubsStack("hc_ResponseSuccess (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,66);
if (RapidSub.canDelegate("hc_responsesuccess")) return b4a.example.main.remoteMe.runUserSub(false, "main","hc_responsesuccess", _response, _taskid);
Debug.locals.put("Response", _response);
Debug.locals.put("TaskId", _taskid);
 BA.debugLineNum = 66;BA.debugLine="Sub hc_ResponseSuccess (Response As OkHttpResponse";
Debug.ShouldStop(2);
 BA.debugLineNum = 67;BA.debugLine="out.InitializeToBytesArray(0) ' I expect less tha";
Debug.ShouldStop(4);
main._out.runVoidMethod ("InitializeToBytesArray",(Object)(BA.numberCast(int.class, 0)));
 BA.debugLineNum = 68;BA.debugLine="Response.GetAsynchronously(\"Response\", out, True,";
Debug.ShouldStop(8);
_response.runVoidMethod ("GetAsynchronously",main.processBA,(Object)(BA.ObjectToString("Response")),(Object)((main._out.getObject())),(Object)(main.mostCurrent.__c.getField(true,"True")),(Object)(_taskid));
 BA.debugLineNum = 69;BA.debugLine="End Sub";
Debug.ShouldStop(16);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _jobdone(RemoteObject _job) throws Exception{
try {
		Debug.PushSubsStack("JobDone (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,203);
if (RapidSub.canDelegate("jobdone")) return b4a.example.main.remoteMe.runUserSub(false, "main","jobdone", _job);
RemoteObject _res = RemoteObject.createImmutable("");
RemoteObject _parser = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.JSONParser");
RemoteObject _listoffiles = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
int _i = 0;
Debug.locals.put("Job", _job);
 BA.debugLineNum = 203;BA.debugLine="Sub JobDone(Job As HttpJob)";
Debug.ShouldStop(1024);
 BA.debugLineNum = 205;BA.debugLine="If Job.Success Then";
Debug.ShouldStop(4096);
if (_job.getField(true,"_success").<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 206;BA.debugLine="Dim res As String";
Debug.ShouldStop(8192);
_res = RemoteObject.createImmutable("");Debug.locals.put("res", _res);
 BA.debugLineNum = 207;BA.debugLine="res = Job.GetString";
Debug.ShouldStop(16384);
_res = _job.runMethod(true,"_getstring");Debug.locals.put("res", _res);
 BA.debugLineNum = 208;BA.debugLine="Log(\"Back from Job:\" & Job.JobName )";
Debug.ShouldStop(32768);
main.mostCurrent.__c.runVoidMethod ("Log",(Object)(RemoteObject.concat(RemoteObject.createImmutable("Back from Job:"),_job.getField(true,"_jobname"))));
 BA.debugLineNum = 209;BA.debugLine="Log(\"Response from server: \" & res)";
Debug.ShouldStop(65536);
main.mostCurrent.__c.runVoidMethod ("Log",(Object)(RemoteObject.concat(RemoteObject.createImmutable("Response from server: "),_res)));
 BA.debugLineNum = 211;BA.debugLine="Dim parser As JSONParser";
Debug.ShouldStop(262144);
_parser = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.JSONParser");Debug.locals.put("parser", _parser);
 BA.debugLineNum = 212;BA.debugLine="parser.Initialize(res)";
Debug.ShouldStop(524288);
_parser.runVoidMethod ("Initialize",(Object)(_res));
 BA.debugLineNum = 214;BA.debugLine="Select Job.JobName";
Debug.ShouldStop(2097152);
switch (BA.switchObjectToInt(_job.getField(true,"_jobname"),BA.ObjectToString("getfiles"))) {
case 0: {
 BA.debugLineNum = 217;BA.debugLine="Dim ListOfFiles As List";
Debug.ShouldStop(16777216);
_listoffiles = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");Debug.locals.put("ListOfFiles", _listoffiles);
 BA.debugLineNum = 218;BA.debugLine="ListOfFiles = parser.NextArray";
Debug.ShouldStop(33554432);
_listoffiles = _parser.runMethod(false,"NextArray");Debug.locals.put("ListOfFiles", _listoffiles);
 BA.debugLineNum = 219;BA.debugLine="If ListOfFiles.Size > 0 Then";
Debug.ShouldStop(67108864);
if (RemoteObject.solveBoolean(">",_listoffiles.runMethod(true,"getSize"),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 220;BA.debugLine="For i = 0 To ListOfFiles.Size - 1";
Debug.ShouldStop(134217728);
{
final int step13 = 1;
final int limit13 = RemoteObject.solve(new RemoteObject[] {_listoffiles.runMethod(true,"getSize"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step13 > 0 && _i <= limit13) || (step13 < 0 && _i >= limit13) ;_i = ((int)(0 + _i + step13))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 222;BA.debugLine="ListView1.AddSingleLine(ListOfFiles.Get(i))";
Debug.ShouldStop(536870912);
main.mostCurrent._listview1.runVoidMethod ("AddSingleLine",(Object)(BA.ObjectToCharSequence(_listoffiles.runMethod(false,"Get",(Object)(BA.numberCast(int.class, _i))))));
 }
}Debug.locals.put("i", _i);
;
 };
 break; }
}
;
 }else {
 BA.debugLineNum = 228;BA.debugLine="ToastMessageShow(\"Error: \" & Job.ErrorMessage, Fa";
Debug.ShouldStop(8);
main.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence(RemoteObject.concat(RemoteObject.createImmutable("Error: "),_job.getField(true,"_errormessage")))),(Object)(main.mostCurrent.__c.getField(true,"False")));
 };
 BA.debugLineNum = 231;BA.debugLine="Job.Release";
Debug.ShouldStop(64);
_job.runVoidMethod ("_release");
 BA.debugLineNum = 232;BA.debugLine="End Sub";
Debug.ShouldStop(128);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _listview1_itemclick(RemoteObject _position,RemoteObject _value) throws Exception{
try {
		Debug.PushSubsStack("ListView1_ItemClick (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,191);
if (RapidSub.canDelegate("listview1_itemclick")) return b4a.example.main.remoteMe.runUserSub(false, "main","listview1_itemclick", _position, _value);
RemoteObject _links = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.Map");
Debug.locals.put("Position", _position);
Debug.locals.put("Value", _value);
 BA.debugLineNum = 191;BA.debugLine="Sub ListView1_ItemClick (Position As Int, Value As";
Debug.ShouldStop(1073741824);
 BA.debugLineNum = 192;BA.debugLine="ProgressDialogShow2(\"Fetching Image ...\", False)";
Debug.ShouldStop(-2147483648);
main.mostCurrent.__c.runVoidMethod ("ProgressDialogShow2",main.mostCurrent.activityBA,(Object)(BA.ObjectToCharSequence("Fetching Image ...")),(Object)(main.mostCurrent.__c.getField(true,"False")));
 BA.debugLineNum = 195;BA.debugLine="CallSub(ImageDownloader, \"ClearCache\")";
Debug.ShouldStop(4);
main.mostCurrent.__c.runMethodAndSync(false,"CallSubNew",main.processBA,(Object)((main.mostCurrent._imagedownloader.getObject())),(Object)(RemoteObject.createImmutable("ClearCache")));
 BA.debugLineNum = 196;BA.debugLine="Dim links As Map";
Debug.ShouldStop(8);
_links = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.Map");Debug.locals.put("links", _links);
 BA.debugLineNum = 198;BA.debugLine="links.Initialize";
Debug.ShouldStop(32);
_links.runVoidMethod ("Initialize");
 BA.debugLineNum = 199;BA.debugLine="links.Put(ImageView1, ServerUrl & \"uploads/\" & Va";
Debug.ShouldStop(64);
_links.runVoidMethod ("Put",(Object)((main.mostCurrent._imageview1.getObject())),(Object)((RemoteObject.concat(main._serverurl,RemoteObject.createImmutable("uploads/"),_value))));
 BA.debugLineNum = 200;BA.debugLine="CallSubDelayed2(ImageDownloader, \"Download\", link";
Debug.ShouldStop(128);
main.mostCurrent.__c.runVoidMethod ("CallSubDelayed2",main.processBA,(Object)((main.mostCurrent._imagedownloader.getObject())),(Object)(BA.ObjectToString("Download")),(Object)((_links)));
 BA.debugLineNum = 201;BA.debugLine="End Sub";
Debug.ShouldStop(256);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
imagedownloader_subs_0._process_globals();
multipartpost_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("b4a.example.main");
imagedownloader.myClass = BA.getDeviceClass ("b4a.example.imagedownloader");
multipartpost.myClass = BA.getDeviceClass ("b4a.example.multipartpost");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 16;BA.debugLine="Private ServerUrl As String = \"http://mohammadnew";
main._serverurl = BA.ObjectToString("http://mohammadnew-001-site6.dtempurl.com/");
 //BA.debugLineNum = 18;BA.debugLine="Dim Chooser As ContentChooser";
main._chooser = RemoteObject.createNew ("anywheresoftware.b4a.phone.Phone.ContentChooser");
 //BA.debugLineNum = 19;BA.debugLine="Dim hc As OkHttpClient";
main._hc = RemoteObject.createNew ("anywheresoftware.b4h.okhttp.OkHttpClientWrapper");
 //BA.debugLineNum = 20;BA.debugLine="Dim out As OutputStream";
main._out = RemoteObject.createNew ("anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper");
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _resizebitmap(RemoteObject _original,RemoteObject _width,RemoteObject _height) throws Exception{
try {
		Debug.PushSubsStack("ResizeBitmap (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,94);
if (RapidSub.canDelegate("resizebitmap")) return b4a.example.main.remoteMe.runUserSub(false, "main","resizebitmap", _original, _width, _height);
RemoteObject _new = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");
RemoteObject _c = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper");
RemoteObject _destrect = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");
Debug.locals.put("original", _original);
Debug.locals.put("width", _width);
Debug.locals.put("height", _height);
 BA.debugLineNum = 94;BA.debugLine="Sub ResizeBitmap(original As Bitmap, width As Int,";
Debug.ShouldStop(536870912);
 BA.debugLineNum = 95;BA.debugLine="Dim new As Bitmap";
Debug.ShouldStop(1073741824);
_new = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");Debug.locals.put("new", _new);
 BA.debugLineNum = 96;BA.debugLine="new.InitializeMutable(width, height)";
Debug.ShouldStop(-2147483648);
_new.runVoidMethod ("InitializeMutable",(Object)(_width),(Object)(_height));
 BA.debugLineNum = 97;BA.debugLine="Dim c As Canvas";
Debug.ShouldStop(1);
_c = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper");Debug.locals.put("c", _c);
 BA.debugLineNum = 98;BA.debugLine="c.Initialize2(new)";
Debug.ShouldStop(2);
_c.runVoidMethod ("Initialize2",(Object)((_new.getObject())));
 BA.debugLineNum = 99;BA.debugLine="Dim destRect As Rect";
Debug.ShouldStop(4);
_destrect = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");Debug.locals.put("destRect", _destrect);
 BA.debugLineNum = 100;BA.debugLine="destRect.Initialize(0, 0, width, height)";
Debug.ShouldStop(8);
_destrect.runVoidMethod ("Initialize",(Object)(BA.numberCast(int.class, 0)),(Object)(BA.numberCast(int.class, 0)),(Object)(_width),(Object)(_height));
 BA.debugLineNum = 101;BA.debugLine="c.DrawBitmap(original, Null, destRect)";
Debug.ShouldStop(16);
_c.runVoidMethod ("DrawBitmap",(Object)((_original.getObject())),(Object)((main.mostCurrent.__c.getField(false,"Null"))),(Object)((_destrect.getObject())));
 BA.debugLineNum = 102;BA.debugLine="Return new";
Debug.ShouldStop(32);
if (true) return _new;
 BA.debugLineNum = 103;BA.debugLine="End Sub";
Debug.ShouldStop(64);
return RemoteObject.createImmutable(null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _response_streamfinish(RemoteObject _success,RemoteObject _taskid) throws Exception{
try {
		Debug.PushSubsStack("Response_StreamFinish (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,71);
if (RapidSub.canDelegate("response_streamfinish")) return b4a.example.main.remoteMe.runUserSub(false, "main","response_streamfinish", _success, _taskid);
RemoteObject _another_buffer = null;
Debug.locals.put("Success", _success);
Debug.locals.put("TaskId", _taskid);
 BA.debugLineNum = 71;BA.debugLine="Sub Response_StreamFinish (Success As Boolean, Tas";
Debug.ShouldStop(64);
 BA.debugLineNum = 72;BA.debugLine="Dim another_buffer () As Byte";
Debug.ShouldStop(128);
_another_buffer = RemoteObject.createNewArray ("byte", new int[] {0}, new Object[]{});Debug.locals.put("another_buffer", _another_buffer);
 BA.debugLineNum = 73;BA.debugLine="another_buffer = out.ToBytesArray";
Debug.ShouldStop(256);
_another_buffer = main._out.runMethod(false,"ToBytesArray");Debug.locals.put("another_buffer", _another_buffer);
 BA.debugLineNum = 74;BA.debugLine="Log (BytesToString(another_buffer, 0, another_buf";
Debug.ShouldStop(512);
main.mostCurrent.__c.runVoidMethod ("Log",(Object)(main.mostCurrent.__c.runMethod(true,"BytesToString",(Object)(_another_buffer),(Object)(BA.numberCast(int.class, 0)),(Object)(_another_buffer.getField(true,"length")),(Object)(RemoteObject.createImmutable("UTF8")))));
 BA.debugLineNum = 75;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}